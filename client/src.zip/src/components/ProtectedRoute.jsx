import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

// Customer routes send visitors to /login. Admin routes pass
// redirectTo="/admin/login" so staff land on the admin sign-in page.
const ProtectedRoute = ({
  children,
  allowedRoles,
  redirectTo = '/login',
}) => {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to={redirectTo} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to={redirectTo} replace />;
  }

  return children;
};

export default ProtectedRoute;
