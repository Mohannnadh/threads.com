const Footer = () => {
  return (
    <footer
      style={{
        backgroundColor: '#111',
        color: '#fff',
        padding: '70px 40px 30px',
      }}
    >
      <div
        style={{
          maxWidth: '1400px',
          margin: '0 auto',
        }}
      >
        {/* Main Footer */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '2fr 1fr 1fr 1fr 1.5fr',
            gap: '50px',
            paddingBottom: '70px',
          }}
        >
          {/* Brand */}
          <div>
            <h2
              style={{
                margin: '0 0 25px',
                fontSize: '32px',
                lineHeight: '0.9',
                letterSpacing: '-0.05em',
                fontWeight: '600',
              }}
            >
              THREADS
              <br />
              .COM
            </h2>

            <p
              style={{
                maxWidth: '300px',
                margin: 0,
                fontSize: '13px',
                lineHeight: '1.6',
                color: '#cfcfcf',
              }}
            >
              Crafting the ultimate foundational wardrobe
              through deliberate design, heavyweight
              textiles, and architectural silhouettes.
            </p>
          </div>

          {/* Shop */}
          <div>
            <FooterTitle>SHOP</FooterTitle>

            <FooterLink>All T-Shirts</FooterLink>
            <FooterLink>Men</FooterLink>
            <FooterLink>Women</FooterLink>
            <FooterLink>Unisex</FooterLink>
          </div>

          {/* Help */}
          <div>
            <FooterTitle>HELP</FooterTitle>

            <FooterLink>Contact</FooterLink>
            <FooterLink>Shipping</FooterLink>
            <FooterLink>Returns & Refunds</FooterLink>
            <FooterLink>FAQ</FooterLink>
          </div>

          {/* Account */}
          <div>
            <FooterTitle>ACCOUNT</FooterTitle>

            <FooterLink>My Account</FooterLink>
            <FooterLink>My Orders</FooterLink>
            <FooterLink>Wishlist</FooterLink>
          </div>

          {/* Company */}
          <div>
            <FooterTitle>COMPANY</FooterTitle>

            <FooterLink>About Threads.com</FooterLink>
            <FooterLink>Sustainability</FooterLink>
            <FooterLink>Privacy Policy</FooterLink>
            <FooterLink>Terms & Conditions</FooterLink>

            <div style={{ marginTop: '35px' }}>
              <FooterTitle>FOLLOW US</FooterTitle>

              <FooterLink>INSTAGRAM</FooterLink>
              <FooterLink>PINTEREST</FooterLink>
              <FooterLink>TIKTOK</FooterLink>
              <FooterLink>X / TWITTER</FooterLink>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div
          style={{
            borderTop: '1px solid #444',
            paddingTop: '20px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '20px',
            flexWrap: 'wrap',
            fontSize: '10px',
            letterSpacing: '0.08em',
            color: '#aaa',
          }}
        >
          <span>
            © 2025 THREADS.COM INC. ALL RIGHTS RESERVED.
          </span>

          <span>
            EDITION: GLOBAL / EN
          </span>

          <span>
            ARCHITECTURAL SILHOUETTES
          </span>
        </div>
      </div>
    </footer>
  );
};

const FooterTitle = ({ children }) => {
  return (
    <p
      style={{
        margin: '0 0 18px',
        fontSize: '10px',
        letterSpacing: '0.14em',
        fontWeight: '600',
        color: '#fff',
      }}
    >
      {children}
    </p>
  );
};

const FooterLink = ({ children }) => {
  return (
    <button
      type="button"
      style={{
        display: 'block',
        border: 'none',
        background: 'none',
        padding: '0',
        margin: '0 0 11px',
        color: '#cfcfcf',
        fontSize: '12px',
        lineHeight: '1.4',
        cursor: 'pointer',
        textAlign: 'left',
      }}
    >
      {children}
    </button>
  );
};

export default Footer;