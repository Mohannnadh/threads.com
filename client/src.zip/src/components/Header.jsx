import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const Header = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();

  return (
    <header
      style={{
        borderBottom: '1px solid #111',
        backgroundColor: '#fff',
        color: '#111',
      }}
    >
      <div
        style={{
          maxWidth: '1400px',
          margin: '0 auto',
          padding: '18px 32px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '30px',
        }}
      >
        {/* Logo */}
        <button
          type="button"
          onClick={() => navigate('/home')}
          style={{
            border: 'none',
            background: 'none',
            padding: 0,
            cursor: 'pointer',
            fontSize: '20px',
            fontWeight: '700',
            letterSpacing: '-0.04em',
            color: '#111',
          }}
        >
          THREADS.COM
        </button>

        {/* Navigation */}
        <nav
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '24px',
          }}
        >
          <button
            type="button"
            onClick={() => navigate('/home')}
            style={navButtonStyle}
          >
            Home
          </button>

          <button
            type="button"
            onClick={() => navigate('/products')}
            style={navButtonStyle}
          >
            Shop
          </button>

          <button
            type="button"
            onClick={() => navigate('/men')}
            style={navButtonStyle}
          >
            Men
          </button>

          <button
            type="button"
            onClick={() => navigate('/women')}
            style={navButtonStyle}
          >
            Women
          </button>

          <button
            type="button"
            onClick={() => navigate('/unisex')}
            style={navButtonStyle}
          >
            Unisex
          </button>

          <button
            type="button"
            onClick={() => navigate('/new-arrivals')}
            style={navButtonStyle}
          >
            New Arrivals
          </button>
        </nav>

        {/* Actions */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
          }}
        >
          <button
  type="button"
  style={iconButtonStyle}
  onClick={() => navigate('/products?search=')}
>
  Search
</button>

          <button type="button" style={iconButtonStyle}>
            Wishlist
          </button>

          <button type="button" style={iconButtonStyle}>
            Cart
          </button>

          <button
            type="button"
            onClick={logout}
            style={iconButtonStyle}
          >
            Logout
          </button>
        </div>
      </div>
    </header>
  );
};

const navButtonStyle = {
  border: 'none',
  background: 'none',
  padding: 0,
  cursor: 'pointer',
  fontSize: '12px',
  textTransform: 'uppercase',
  letterSpacing: '0.08em',
  color: '#111',
};

const iconButtonStyle = {
  border: 'none',
  background: 'none',
  padding: 0,
  cursor: 'pointer',
  fontSize: '11px',
  textTransform: 'uppercase',
  letterSpacing: '0.06em',
  color: '#111',
};

export default Header;