
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import './Header.css';
import { Icon } from './Icon.jsx';

const Header = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const goTo = (path) => {
    setMenuOpen(false);
    setProfileOpen(false);
    navigate(path);
  };



  const handleLogout = () => {
    console.log('Logout button clicked');

    setMenuOpen(false);
    setProfileOpen(false);

    logout();
    console.log('Logout function executed');

    navigate('/login', { replace: true });
  };



  return (
    <header className="site-header">
      <div className="header-inner">
        <button
          type="button"
          className="header-logo"
          onClick={() => goTo('/home')}
        >
          THREADS.COM
        </button>

        <button
          type="button"
          className="mobile-menu-toggle"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? 'CLOSE' : 'MENU'}
        </button>

        <nav
          className={`header-nav ${menuOpen ? 'is-open' : ''}`}
          aria-label="Main navigation"
        >
          <button type="button" onClick={() => goTo('/home')}>
            Home
          </button>
          <button type="button" onClick={() => goTo('/products')}>
            Shop
          </button>
          <button type="button" onClick={() => goTo('/products?gender=men')}>
            Men
          </button>

          <button type="button" onClick={() => goTo('/products?gender=women')}>
            Women
          </button>

          <button type="button" onClick={() => goTo('/products?gender=unisex')}>
            Unisex
          </button>

          <button type="button" onClick={() => goTo('/products?sort=recent')}>
            New Arrivals
          </button>
        </nav>


        <div className="header-actions">
          <button type="button" onClick={() => goTo('/products?search=')}>
            Search
          </button>

          <button type="button" onClick={() => goTo('/wishlist')}>
            Wishlist
          </button>


          <button type="button" onClick={() => goTo('/cart')}>
            Cart
          </button>

          <div className="profile-menu">
            <button
              type="button"
              className="profile-toggle"
              aria-label="Open profile menu"
              aria-expanded={profileOpen}
              onClick={() => setProfileOpen((open) => !open)}
            >
              <span className="profile-icon" aria-hidden="true"><Icon name="user" size={20} /></span>
            </button>

            {profileOpen && (
              <div className="profile-dropdown">
                <button type="button" onClick={() => {
                  setProfileOpen(false);
                  goTo('/profile');
                }}>
                  My Profile
                </button>

                <button type="button" onClick={() => {
                  setProfileOpen(false);
                  goTo('/orders');
                }}>
                  My Orders
                </button>
                <button
                  type="button"
                  onClick={() => {
                    console.log('Logout button clicked');
                    handleLogout();
                  }}
                >
                  Logout
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};

export default Header;
