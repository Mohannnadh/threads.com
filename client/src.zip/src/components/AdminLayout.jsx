import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { Icon } from './Icon.jsx';
import { STATUS_TONE, statusLabel } from '../utils/adminFormat.js';
import '../styles/admin.css';

const NAV_ITEMS = [
  { to: '/admin', label: 'Overview', icon: 'dashboard', end: true },
  { to: '/admin/orders', label: 'Orders', icon: 'bag' },
  { to: '/admin/products', label: 'Products', icon: 'package' },
];

export const StatusPill = ({ status, tone }) => (
  <span
    className={`admin-pill admin-pill-${
      tone || STATUS_TONE[status] || 'neutral'
    }`}
  >
    {statusLabel(status)}
  </span>
);

export const Notice = ({ tone = 'success', onClose, children }) => (
  <div
    className={`admin-notice admin-notice-${tone}`}
    role={tone === 'error' ? 'alert' : 'status'}
  >
    <Icon name={tone === 'error' ? 'x' : 'check'} size={16} />
    <div className="admin-notice-text">{children}</div>
    {onClose && (
      <button
        type="button"
        className="admin-icon-button"
        onClick={onClose}
        aria-label="Dismiss message"
      >
        <Icon name="x" size={14} />
      </button>
    )}
  </div>
);

const AdminLayout = ({ title, subtitle, actions, children }) => {
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/admin/login', { replace: true });
  };

  return (
    <div className="admin-app">
      <aside className="admin-sidebar">
        <div className="admin-brand">
          <span className="admin-brand-mark" aria-hidden="true">
            T
          </span>
          <span className="admin-brand-text">
            Threads<span>.com</span>
          </span>
        </div>

        <nav className="admin-nav" aria-label="Admin sections">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className="admin-nav-link"
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="admin-sidebar-footer">
          <div className="admin-user">
            <strong>{user?.name || 'Administrator'}</strong>
            <span>Store admin</span>
          </div>

          <button
            type="button"
            className="admin-icon-button"
            onClick={handleLogout}
            aria-label="Log out"
            title="Log out"
          >
            <Icon name="logout" />
          </button>
        </div>
      </aside>

      <main className="admin-main">
        <header className="admin-page-header">
          <div>
            <h1 className="admin-title">{title}</h1>
            {subtitle && <p className="admin-subtitle">{subtitle}</p>}
          </div>

          {actions && <div className="admin-page-actions">{actions}</div>}
        </header>

        {children}
      </main>
    </div>
  );
};

export default AdminLayout;
