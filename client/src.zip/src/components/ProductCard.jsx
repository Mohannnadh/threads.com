import {useState} from 'react';
import { useNavigate } from 'react-router-dom';
import blackTshirt from '../assets/products/essential-black-tee.png';
import abcImage from '../assets/products/abc.png';

const ProductCard = ({ product }) => {
  const navigate = useNavigate();
  const [isWishlisted,setIsWishlisted]=useState(false);
  return (
    <article
      onClick={() => navigate(`/products/${product._id}`)}
      style={{
        minWidth: 0,
        backgroundColor: '#fff',
        color: '#111',
        cursor: 'pointer',
      }}
    >
      {/* Product Image */}
      <div
        style={{
          position: 'relative',
          aspectRatio: '3 / 4',
          backgroundColor: '#f3f1ed',
          overflow: 'hidden',
          marginBottom: '14px',
        }}
      >
        <img
        className="product-card-image"
          src={
            product.images && product.images.length > 0
              ? product.images[0] === 'abc.png'
                ? abcImage
                : blackTshirt
              : blackTshirt
          }
          alt={product.name}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain',
            display: 'block',
            transition:'transform 0.4s ease',
          }}
        />

        {/* Wishlist Heart */}
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            setIsWishlisted((previous) => !previous);
          }}
          aria-label="Add to wishlist"
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '1px solid #111',
            borderRadius: '50%',
            backgroundColor: '#fff',
            color: '#111',
            fontSize: '18px',
            lineHeight: 1,
            cursor: 'pointer',
          }}
        >
         {isWishlisted ? '♥' : '♡'}
        </button>

        {/* Stock status */}
        {product.stock === 0 && (
          <span
            style={{
              position: 'absolute',
              top: '12px',
              left: '12px',
              padding: '5px 8px',
              backgroundColor: '#fff',
              fontSize: '9px',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            Out of stock
          </span>
        )}
      </div>

      {/* Product Information */}
      <div
       style={{
        padding:'0 2px',
       }}
       >
          {/* Category*/}
        <p
          style={{
            margin: '0 0 7px',
            fontSize: '9px',
            lineHeight: '1.4',
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
            color: '#777',
          }}
        >
          {product.category}
        </p>
          {/*Product Name */}
        <h2
          style={{
            margin: '0 0 8px',
            fontSize: '14px',
            lineHeight: '1.3',
            fontWeight: '500',
            letterSpacing: '-0.015em',
          }}
        >
          {product.name}
        </h2>
          {/*Price */}
        <p
          style={{
            margin: 0,
            fontSize: '12px',
            lineHeight: '1.4',
            fontWeight: '500',
            letterSpacing:'0.01em',
          }}
        >
          ₹{product.price}
        </p>
      </div>
    </article>
  );
};

export default ProductCard;