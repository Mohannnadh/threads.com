import { Routes, Route, Navigate } from 'react-router-dom';

import Login from './page/Login.jsx';
import Register from './page/Register.jsx';
import ForgotPassword from './page/ForgotPassword.jsx';
import VerifyOtp from './page/VerifyOtp.jsx';
import ResetPassword from './page/ResetPassword.jsx';
import Home from './page/Home.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Products from './page/Products.jsx';
import ProductDetails from './page/ProductDetails.jsx';
import Cart from './page/Cart.jsx';


function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={<Navigate to="/login" replace />}
      />

      <Route
        path="/login"
        element={<Login />}
      />

      <Route
        path="/register"
        element={<Register />}
      />

      <Route
        path="/forgot-password"
        element={<ForgotPassword />}
      />

      <Route
        path="/verify-otp"
        element={<VerifyOtp />}
      />

      <Route
        path="/reset-password"
        element={<ResetPassword />}
      />

      <Route
        path="/home"
        element={
        <ProtectedRoute>
      <Home />
    </ProtectedRoute>}
      />
      <Route
  path="/products"
  element={<Products />}
      />
      <Route
        path="/products/:id"
        element={<ProductDetails />}
        />

        <Route path="/cart"
         element={<Cart />} 
        />
    </Routes>
  );
}

export default App;

