
import {
  createContext,
  useContext,
  useEffect,
  useState,
} from 'react';

const CartContext = createContext(null);

export const useCart = () => {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error(
      'useCart must be used inside CartProvider'
    );
  }

  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    try {
      const savedCart = localStorage.getItem('threads-cart');
      return savedCart ? JSON.parse(savedCart) : [];
    } catch (error) {
      console.error('Could not load saved cart:', error);
      return [];
    }
  });

  // Save cart whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(
        'threads-cart',
        JSON.stringify(cartItems)
      );
    } catch (error) {
      console.error('Could not save cart:', error);
    }
  }, [cartItems]);

  const addToCart = (product, size, quantity = 1) => {
    if (!product?._id || !size) {
      console.error('Product or size is missing.');
      return;
    }

    const stock = Number(product.stock);
    const amount = Number(quantity);

    if (
      !Number.isFinite(stock) ||
      stock <= 0 ||
      !Number.isInteger(amount) ||
      amount < 1
    ) {
      console.error('Invalid quantity or stock.');
      return;
    }

    setCartItems((currentItems) => {
      const existingItem = currentItems.find(
        (item) =>
          item._id === product._id &&
          item.size === size
      );

      if (existingItem) {
        return currentItems.map((item) => {
          if (
            item._id === product._id &&
            item.size === size
          ) {
            return {
              ...item,
              quantity: Math.min(
                stock,
                item.quantity + amount
              ),
            };
          }

          return item;
        });
      }

      return [
        ...currentItems,
        {
          ...product,
          size,
          quantity: Math.min(stock, amount),
        },
      ];
    });
  };

  const removeFromCart = (productId, size) => {
    setCartItems((currentItems) =>
      currentItems.filter(
        (item) =>
          !(
            item._id === productId &&
            item.size === size
          )
      )
    );
  };

  const updateQuantity = (productId, size, quantity) => {
    const amount = Number(quantity);

    setCartItems((currentItems) =>
      currentItems.map((item) => {
        if (
          item._id === productId &&
          item.size === size
        ) {
          return {
            ...item,
            quantity: Math.max(
              1,
              Math.min(
                Number(item.stock) || 1,
                Number.isFinite(amount) ? amount : 1
              )
            ),
          };
        }

        return item;
      })
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const cartCount = cartItems.reduce(
    (total, item) => total + Number(item.quantity || 0),
    0
  );

  const cartTotal = cartItems.reduce(
    (total, item) =>
      total +
      Number(item.price || 0) *
        Number(item.quantity || 0),
    0
  );

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};