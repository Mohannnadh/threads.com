
import { API_BASE_URL } from '../config.js';

const API_URL = `${API_BASE_URL}/api/admin`;
const ORDERS_API_URL = `${API_BASE_URL}/api/orders`;

// Get admin dashboard statistics
const getDashboardStats = async (token) => {
  const response = await fetch(`${API_URL}/dashboard`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Failed to load dashboard');
  }

  return data.stats;
};

// One page of customer orders with filters (admin only).
// params: { page, limit, status, search }
// Returns { orders, counts, pagination }.
const getOrdersPage = async (token, params = {}) => {
  const query = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== 'ALL') {
      query.set(key, String(value));
    }
  });

  const text = query.toString();

  const response = await fetch(
    `${ORDERS_API_URL}/admin${text ? `?${text}` : ''}`,
    {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Failed to load orders');
  }

  return {
    orders: data.orders,
    counts: data.counts,
    pagination: data.pagination,
  };
};

// Get all customer orders (admin only). Returns the first page only.
const getAllOrders = async (token) => {
  const response = await fetch(`${ORDERS_API_URL}/admin`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Failed to load orders');
  }

  return data.orders;
};

// Update an order's status (admin only)
const updateOrderStatus = async (token, orderId, orderStatus) => {
  const response = await fetch(
    `${ORDERS_API_URL}/admin/${orderId}/status`,
    {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ orderStatus }),
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Failed to update order status');
  }

  return data.order;
};

export {
  getDashboardStats,
  getAllOrders,
  getOrdersPage,
  updateOrderStatus,
};
