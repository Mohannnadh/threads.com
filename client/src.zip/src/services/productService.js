
import { API_BASE_URL } from '../config.js';

const API_URL = `${API_BASE_URL}/api/products`;

const handleResponse = async (response) => {
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Request failed');
  }

  return data;
};

// Build a query string, skipping empty or default values.
const toQuery = (params = {}) => {
  const query = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== 'all') {
      query.set(key, String(value));
    }
  });

  const text = query.toString();
  return text ? `?${text}` : '';
};

// Get one page of products.
// params: { page, limit, search, gender, category, sort }
const getProducts = async (params = {}) => {
  const response = await fetch(`${API_URL}${toQuery(params)}`);
  return handleResponse(response);
};

// Distinct category names for the category filter.
const getProductCategories = async () => {
  const response = await fetch(`${API_URL}/categories`);
  const data = await handleResponse(response);
  return data.categories || [];
};

// Get one product
const getProductById = async (id) => {
  const response = await fetch(`${API_URL}/${id}`);
  return handleResponse(response);
};

// Shared helper for protected admin requests
const adminRequest = async (url, method, product, token) => {
  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    ...(product ? { body: JSON.stringify(product) } : {}),
  });

  return handleResponse(response);
};

// Create product
const createProduct = (product, token) =>
  adminRequest(API_URL, 'POST', product, token);

// Update product
const updateProduct = (id, product, token) =>
  adminRequest(`${API_URL}/${id}`, 'PUT', product, token);

// Delete product
const deleteProduct = (id, token) =>
  adminRequest(`${API_URL}/${id}`, 'DELETE', null, token);

export {
  getProducts,
  getProductCategories,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
};
