
import { useEffect, useRef ,useState } from 'react';
import { getProducts } from '../services/productService';
import ProductCard from '../components/ProductCard.jsx';
import Header from '../components/Header.jsx';
import Footer from '../components/Footer.jsx';
import {useSearchParams } from 'react-router-dom';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [sortBy, setSortBy] = useState('recent');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedGender, setSelectedGender] = useState('all');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchParams] = useSearchParams();
  const searchInputRef = useRef(null);

  // Fetch products from the backend
  useEffect(() => {
    const loadProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(data.products);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);
      // Focus the search input when opened from the header
useEffect(() => {
  if (searchParams.has('search')) {
    searchInputRef.current?.focus();
  }
}, [searchParams]);

  // Loading state
  if (loading) {
    return <p>Loading products...</p>;
  }

  // Error state
  if (error) {
    return <p>{error}</p>;
  }

  // Filter products by category and gender
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      selectedCategory === 'all' ||
      product.category === selectedCategory;

    const matchesGender =
      selectedGender === 'all' ||
      product.gender === selectedGender;

    return matchesSearch && matchesCategory && matchesGender;
  });

  // Sort the filtered products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'low-high') {
      return a.price - b.price;
    }

    if (sortBy === 'high-low') {
      return b.price - a.price;
    }

    return new Date(b.createdAt) - new Date(a.createdAt);
  });

  // Get available categories from the fetched products
  const categories = [
    ...new Set(
      products
        .map((product) => product.category)
        .filter(Boolean)
    ),
  ];

  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: '#fff',
        color: '#111',
      }}
    >
      <Header />

      <main>
        {/* Page Introduction */}
        <section
          style={{
            maxWidth: '1400px',
            margin: '0 auto',
            padding: '70px 32px 50px',
            borderBottom: '1px solid #111',
          }}
        >
          <p
            style={{
              margin: '0 0 14px',
              fontSize: '10px',
              letterSpacing: '0.16em',
              textTransform: 'uppercase',
              color: '#777',
            }}
          >
            SHOP
          </p>

          <h1
            style={{
              margin: 0,
              fontSize: 'clamp(48px, 7vw, 92px)',
              lineHeight: '0.9',
              letterSpacing: '-0.06em',
              fontWeight: '500',
              color: '#111'
            }}
          >
            ALL PRODUCTS
          </h1>
        </section>

        {/* Product Section */}
        <section
          style={{
            maxWidth: '1400px',
            margin: '0 auto',
            padding: '40px 32px 100px',
          }}
        >
          {/* Product Toolbar */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '16px',
              marginBottom: '30px',
              paddingBottom: '18px',
              borderBottom: '1px solid #111',
            }}
          >
            
{/* Search Products */}
<input
  type="search"
  placeholder="Search products..."
  ref={searchInputRef}
  placeholder ="search products..."
  value={searchTerm}
  onChange={(event) => setSearchTerm(event.target.value)}
  style={{
    padding: '10px 12px',
    border: '1px solid #ddd',
    backgroundColor: '#fff',
    color: '#111',
    fontSize: '12px',
    outline: 'none',
    minWidth: '180px',
  }}
/>
            {/* Dynamic Product Count */}
            <p
              style={{
                margin: 0,
                fontSize: '10px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: '#555',
              }}
            >
              {filteredProducts.length} PRODUCTS
            </p>

            {/* Filter and Sort Controls */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '16px',
                flexWrap: 'wrap',
              }}
            >
              {/* Category Filter */}
              <label
                style={{
                  fontSize: '10px',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: '#555',
                }}
              >
                CATEGORY

                <select
                  value={selectedCategory}
                  onChange={(event) =>
                    setSelectedCategory(event.target.value)
                  }
                  style={{
                    marginLeft: '8px',
                    border: 'none',
                    backgroundColor: 'transparent',
                    fontSize: '10px',
                    color: '#111',
                    cursor: 'pointer',
                    outline: 'none',
                  }}
                >
                  <option value="all">All Categories</option>

                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </label>

              {/* Gender Filter */}
              <label
                style={{
                  fontSize: '10px',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: '#555',
                }}
              >
                GENDER

                <select
                  value={selectedGender}
                  onChange={(event) =>
                    setSelectedGender(event.target.value)
                  }
                  style={{
                    marginLeft: '8px',
                    border: 'none',
                    backgroundColor: 'transparent',
                    fontSize: '10px',
                    color: '#111',
                    cursor: 'pointer',
                    outline: 'none',
                  }}
                >
                  <option value="all">All</option>
                  <option value="men">Men</option>
                  <option value="women">Women</option>
                  <option value="unisex">Unisex</option>
                </select>
              </label>

              
<button
  type="button"
  onClick={() => {
    setSelectedCategory('all');
    setSelectedGender('all');
  }}
  style={{
    padding: '8px 0',
    border: 'none',
    borderBottom: '1px solid #111',
    backgroundColor: 'transparent',
    color: '#111',
    fontSize: '10px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    cursor: 'pointer',
  }}
>
  Clear Filters
</button>

              {/* Sort Products */}
              <label
                htmlFor="sort-products"
                style={{
                  fontSize: '10px',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: '#555',
                }}
              >
                SORT BY

                <select
                  id="sort-products"
                  value={sortBy}
                  onChange={(event) =>
                    setSortBy(event.target.value)
                  }
                  style={{
                    marginLeft: '8px',
                    border: 'none',
                    backgroundColor: 'transparent',
                    fontSize: '10px',
                    letterSpacing: '0.04em',
                    color: '#111',
                    cursor: 'pointer',
                    outline: 'none',
                  }}
                >
                  <option value="recent">Recently Added</option>
                  <option value="low-high">
                    Price: Low to High
                  </option>
                  <option value="high-low">
                    Price: High to Low
                  </option>
                </select>
              </label>
            </div>
          </div>

          {/* Product Grid or Empty State */}
          {filteredProducts.length === 0 ? (
            <p
              style={{
                textAlign: 'center',
                padding: '80px 0',
                fontSize: '14px',
                color: '#555',
              }}
            >
              No products available.
            </p>
          ) : (
            <div
              className="products-grid"
              style={{
                display: 'grid',
                gap: '32px 20px',
              }}
            >
              {sortedProducts.map((product) => (
                <ProductCard
                  key={product._id}
                  product={product}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Products;