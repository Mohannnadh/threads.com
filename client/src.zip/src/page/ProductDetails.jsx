import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getProductById } from '../services/productService';
import { useCart } from '../context/CartContext.jsx';
import blackTshirt from '../assets/products/essential-black-tee.png';

const ProductDetails = () => {
  const { id } = useParams();
  const { addToCart } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [cartMessage, setCartMessage] = useState('');

  useEffect(() => {
    const loadProduct = async () => {
      try {
        setLoading(true);
        setError('');

        const data = await getProductById(id);

        // Support either a { product: ... } response
        // or a product object returned directly.
        const fetchedProduct = data?.product ?? data;

        if (!fetchedProduct?._id) {
          throw new Error('Product not found.');
        }

        setProduct(fetchedProduct);
        setSelectedSize('');
        setQuantity(1);
        setCartMessage('');
      } catch (err) {
        setError(err.message || 'Failed to load product.');
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [id]);

  const handleAddToCart = () => {
    setCartMessage('');

    console.log('Product selected:', product);
    console.log('Selected size:', selectedSize);
    console.log('Selected quantity:', quantity);

    if (!product?._id) {
      setCartMessage('Product information is missing.');
      return;
    }

    if (!selectedSize) {
      setCartMessage('Please select a size first.');
      return;
    }

    const stock = Number(product.stock);
    const selectedQuantity = Number(quantity);

    if (!Number.isFinite(stock) || stock <= 0) {
      setCartMessage('Sorry, this product is out of stock.');
      return;
    }

    if (
      !Number.isInteger(selectedQuantity) ||
      selectedQuantity < 1 ||
      selectedQuantity > stock
    ) {
      setCartMessage('Please select a valid quantity.');
      return;
    }

    try {
      console.log('Calling addToCart now...');

      addToCart(product, selectedSize, selectedQuantity);

      setCartMessage('ADDED TO CART SUCCESSFULLY');
    } catch (err) {
      console.error('Add to cart failed:', err);
      setCartMessage('Unable to add this product. Please try again.');
    }
  };

  if (loading) {
    return <p>Loading product...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  if (!product) {
    return <p>Product not found.</p>;
  }

  return (
    <main
      style={{
        maxWidth: '1400px',
        margin: '0 auto',
        padding: '60px 32px 100px',
        color: '#111',
        backgroundColor: '#fff',
      }}
    >
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1.15fr 0.85fr',
          gap: '70px',
          alignItems: 'start',
        }}
      >
        {/* Product Image */}
        <div
          style={{
            backgroundColor: '#f3f1ed',
            aspectRatio: '3 / 4',
            overflow: 'hidden',
          }}
        >
          <img
            src={blackTshirt}
            alt={product.name}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
              display: 'block',
            }}
          />
        </div>

        {/* Product Information */}
        <div style={{ paddingTop: '20px' }}>
          <p
            style={{
              margin: '0 0 14px',
              fontSize: '10px',
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              color: '#777',
            }}
          >
            {product.category}
          </p>

          <h1
            style={{
              margin: '0 0 18px',
              fontSize: 'clamp(36px, 5vw, 72px)',
              lineHeight: '0.95',
              letterSpacing: '-0.05em',
              fontWeight: '500',
            }}
          >
            {product.name}
          </h1>

          <p
            style={{
              margin: '0 0 25px',
              fontSize: '16px',
              fontWeight: '500',
            }}
          >
            ₹{product.price}
          </p>

          <p
            style={{
              maxWidth: '520px',
              margin: '0 0 35px',
              fontSize: '14px',
              lineHeight: '1.7',
              color: '#555',
            }}
          >
            {product.description}
          </p>

          {/* Gender */}
          <div
            style={{
              borderTop: '1px solid #111',
              paddingTop: '18px',
            }}
          >
            <p
              style={{
                margin: '0 0 8px',
                fontSize: '10px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
              }}
            >
              Gender
            </p>

            <p style={{ margin: 0, fontSize: '13px' }}>
              {product.gender}
            </p>
          </div>

          {/* Size Selection */}
          <div
            style={{
              borderTop: '1px solid #ddd',
              marginTop: '25px',
              paddingTop: '18px',
            }}
          >
            <p
              style={{
                margin: '0 0 12px',
                fontSize: '10px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
              }}
            >
              Select Size
            </p>

            <div
              style={{
                display: 'flex',
                gap: '10px',
                flexWrap: 'wrap',
              }}
            >
              {(product.sizes ?? []).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => {
                    setSelectedSize(size);
                    setCartMessage('');
                  }}
                  aria-pressed={selectedSize === size}
                  style={{
                    width: '48px',
                    height: '44px',
                    border: '1px solid #111',
                    backgroundColor:
                      selectedSize === size ? '#111' : '#fff',
                    color: selectedSize === size ? '#fff' : '#111',
                    cursor: 'pointer',
                  }}
                >
                  {size}
                </button>
              ))}
            </div>

            {(!product.sizes || product.sizes.length === 0) && (
              <p style={{ fontSize: '12px', color: '#777' }}>
                No sizes are available for this product.
              </p>
            )}

            {!selectedSize && (
              <p style={{ fontSize: '12px', color: '#777' }}>
                Please select a size.
              </p>
            )}
          </div>

          {/* Quantity Selection */}
          <div
            style={{
              borderTop: '1px solid #ddd',
              marginTop: '25px',
              paddingTop: '18px',
            }}
          >
            <p
              style={{
                margin: '0 0 12px',
                fontSize: '10px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
              }}
            >
              Quantity
            </p>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '18px',
              }}
            >
              <button
                type="button"
                onClick={() => {
                  setQuantity((current) => Math.max(1, current - 1));
                  setCartMessage('');
                }}
                disabled={quantity <= 1 || product.stock <= 0}
                style={{
                  width: '40px',
                  height: '40px',
                  border: '1px solid #111',
                  backgroundColor: '#fff',
                  cursor:
                    quantity <= 1 || product.stock <= 0
                      ? 'not-allowed'
                      : 'pointer',
                }}
              >
                −
              </button>

              <span
                style={{
                  fontSize: '15px',
                  minWidth: '20px',
                  textAlign: 'center',
                }}
              >
                {quantity}
              </span>

              <button
                type="button"
                onClick={() => {
                  setQuantity((current) =>
                    Math.min(Number(product.stock) || 1, current + 1)
                  );
                  setCartMessage('');
                }}
                disabled={quantity >= product.stock || product.stock <= 0}
                style={{
                  width: '40px',
                  height: '40px',
                  border: '1px solid #111',
                  backgroundColor: '#fff',
                  cursor:
                    quantity >= product.stock || product.stock <= 0
                      ? 'not-allowed'
                      : 'pointer',
                }}
              >
                +
              </button>
            </div>
          </div>

          {/* Add to Cart */}
          <button
            type="button"
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
            style={{
              width: '100%',
              minHeight: '52px',
              marginTop: '28px',
              padding: '14px 20px',
              border: '1px solid #111',
              backgroundColor: product.stock > 0 ? '#111' : '#999',
              color: '#fff',
              fontSize: '11px',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              cursor: product.stock > 0 ? 'pointer' : 'not-allowed',
            }}
          >
            {product.stock > 0 ? 'ADD TO CART' : 'OUT OF STOCK'}
          </button>

          {cartMessage && (
            <p
              role="status"
              aria-live="polite"
              style={{
                marginTop: '12px',
                fontSize: '12px',
                color: '#333',
              }}
            >
              {cartMessage}
            </p>
          )}

          {/* Availability */}
          <div
            style={{
              borderTop: '1px solid #111',
              marginTop: '25px',
              paddingTop: '18px',
            }}
          >
            <p
              style={{
                margin: '0 0 8px',
                fontSize: '10px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
              }}
            >
              Availability
            </p>

            <p style={{ margin: 0, fontSize: '13px' }}>
              {product.stock > 0
                ? `${product.stock} available`
                : 'Out of stock'}
            </p>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ProductDetails;
