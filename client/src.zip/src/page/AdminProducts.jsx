
import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import {getProducts,createProduct,updateProduct,deleteProduct,} from '../services/productService.js';
import { getDashboardStats } from '../services/adminService.js';
import Pagination from '../components/Pagination.jsx';
import useDebouncedValue from '../hooks/useDebouncedValue.js';

const PAGE_SIZE = 10;
import '../styles/admin.css';
import { Icon } from '../components/Icon.jsx';
import AdminLayout, { Notice } from '../components/AdminLayout.jsx';

const initialForm = {
  name: '',
  description: '',
  price: '',
  category: '',
  gender: 'unisex',
  images: '',
  sizes: 'S, M, L, XL',
  colors: 'Black, White',
  stock: '0',
  isFeatured: false,
};

const formatPrice = (price) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(Number(price) || 0);

function AdminProducts() {
  const { token } = useAuth();

  const [products, setProducts] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [stats, setStats] = useState({ total: 0, inStock: 0, lowStock: 0 });
  const [form, setForm] = useState(initialForm);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebouncedValue(search.trim(), 300);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Bumping this counter reloads the current page (after save/delete/refresh).
  const [refreshKey, setRefreshKey] = useState(0);

  // Loads the current page whenever the page, search or refresh key changes.
  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      try {
        const [listResult, statsResult] = await Promise.all([
          getProducts({ page, limit: PAGE_SIZE, search: debouncedSearch }),
          getDashboardStats(token).catch(() => null),
        ]);

        if (cancelled) return;

        const { products: pageItems, pagination: meta } = listResult;

        // If the current page no longer exists (e.g. after a delete), step back.
        if (pageItems.length === 0 && meta.totalPages > 0 && page > meta.totalPages) {
          setPage(meta.totalPages);
          return;
        }

        setError('');
        setProducts(pageItems || []);
        setPagination(meta);

        if (statsResult) {
          setStats(statsResult.products);
        }
      } catch (err) {
        if (!cancelled) setError(err.message || 'Unable to load products.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    run();

    return () => {
      cancelled = true;
    };
  }, [page, debouncedSearch, token, refreshKey]);

  // Reload the current page from an event handler (sets loading first).
  const reloadProducts = () => {
    setLoading(true);
    setRefreshKey((key) => key + 1);
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const resetForm = () => {
    setForm(initialForm);
    setEditingId(null);
  };

  const handleEdit = (product) => {
    setEditingId(product._id);
    setForm({
      name: product.name || '',
      description: product.description || '',
      price: String(product.price ?? ''),
      category: product.category || '',
      gender: product.gender || 'unisex',
      images: Array.isArray(product.images)
        ? product.images.join(', ')
        : '',
      sizes: Array.isArray(product.sizes)
        ? product.sizes.join(', ')
        : 'S, M, L, XL',
      colors: Array.isArray(product.colors)
        ? product.colors.join(', ')
        : 'Black, White',
      stock: String(product.stock ?? 0),
      isFeatured: Boolean(product.isFeatured),
    });

    setError('');
    setSuccess('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setError('');
    setSuccess('');

    if (
      !form.name.trim() ||
      !form.description.trim() ||
      !form.category.trim()
    ) {
      setError('Please fill in the product name, description, and category.');
      return;
    }

    if (form.price.trim() === '' || Number(form.price) < 0 ||
        !Number.isFinite(Number(form.price))) {
      setError('Enter a valid price greater than or equal to zero.');
      return;
    }

    if (
      form.stock.trim() === '' ||
      !Number.isInteger(Number(form.stock)) ||
      Number(form.stock) < 0
    ) {
      setError('Stock must be a non-negative whole number.');
      return;
    }

    const productData = {
      ...form,
      name: form.name.trim(),
      description: form.description.trim(),
      category: form.category.trim(),
      price: Number(form.price),
      stock: Number(form.stock),
      images: form.images.split(',').map((item) => item.trim()).filter(Boolean),
      sizes: form.sizes.split(',').map((item) => item.trim()).filter(Boolean),
      colors: form.colors.split(',').map((item) => item.trim()).filter(Boolean),
    };

    try {
      setSaving(true);

      if (editingId) {
        await updateProduct(editingId, productData, token);
        setSuccess('Product updated successfully.');
      } else {
        await createProduct(productData, token);
        setSuccess('Product created successfully.');
      }

      resetForm();
      reloadProducts();
    } catch (err) {
      setError(err.message || 'Unable to save product.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (product) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete "${product.name}"?`
    );

    if (!confirmed) return;

    setError('');
    setSuccess('');

    try {
      await deleteProduct(product._id, token);

      if (editingId === product._id) {
        resetForm();
      }

      setSuccess('Product deleted successfully.');
      reloadProducts();
    } catch (err) {
      setError(err.message || 'Unable to delete product.');
    }
  };

  return (
    <AdminLayout
      title="Products"
      subtitle="Catalogue, pricing and stock in one place."
      actions={
        <button
          type="button"
          className="admin-button admin-button-primary"
          onClick={() => {
          resetForm();
          setError('');
          setSuccess('');
          document.getElementById('product-form')?.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
          }}
        >
          + Add product
        </button>
      }
    >
          {error && (
            <Notice tone="error" onClose={() => setError('')}>
              {error}
            </Notice>
          )}

          {success && (
            <Notice onClose={() => setSuccess('')}>{success}</Notice>
          )}

          <section className="admin-stats" aria-label="Product statistics">
            <article className="admin-stat-card">
              <div className="admin-stat-label">Total products</div>
              <div className="admin-stat-value">{stats.total}</div>
              <div className="admin-muted">Products in your catalogue</div>
            </article>

            <article className="admin-stat-card">
              <div className="admin-stat-label">Available products</div>
              <div className="admin-stat-value">{stats.inStock}</div>
              <div className="admin-muted">Products with stock available</div>
            </article>

            <article className="admin-stat-card">
              <div className="admin-stat-label">Low or out of stock</div>
              <div className="admin-stat-value">{stats.lowStock}</div>
              <div className="admin-muted">Products with 5 units or fewer</div>
            </article>
          </section>

          <section className="admin-panel" id="product-form">
            <div className="admin-panel-header">
              <div>
                <h2 className="admin-panel-title">
                  {editingId ? 'Edit product' : 'Add a new product'}
                </h2>
                <p className="admin-muted">
                  {editingId
                    ? 'Update the product details below.'
                    : 'Enter the details to add an item to your catalogue.'}
                </p>
              </div>

              {editingId && (
                <span className="admin-stock">EDITING</span>
              )}
            </div>

            <form onSubmit={handleSubmit}>
              <div className="admin-form-grid">
                <div className="admin-field">
                  <label htmlFor="name">Product name *</label>
                  <input
                    id="name"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="e.g. Essential Black Tee"
                    required
                  />
                </div>

                <div className="admin-field">
                  <label htmlFor="category">Category *</label>
                  <input
                    id="category"
                    name="category"
                    value={form.category}
                    onChange={handleChange}
                    placeholder="e.g. T-shirts"
                    required
                  />
                </div>

                <div className="admin-field admin-field-full">
                  <label htmlFor="description">Description *</label>
                  <textarea
                    id="description"
                    name="description"
                    value={form.description}
                    onChange={handleChange}
                    placeholder="Describe the product..."
                    rows={3}
                    required
                  />
                </div>

                <div className="admin-field">
                  <label htmlFor="price">Price (₹) *</label>
                  <input
                    id="price"
                    name="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={form.price}
                    onChange={handleChange}
                    placeholder="999"
                    required
                  />
                </div>

                <div className="admin-field">
                  <label htmlFor="stock">Stock quantity *</label>
                  <input
                    id="stock"
                    name="stock"
                    type="number"
                    min="0"
                    step="1"
                    value={form.stock}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="admin-field">
                  <label htmlFor="gender">Gender</label>
                  <select
                    id="gender"
                    name="gender"
                    value={form.gender}
                    onChange={handleChange}
                  >
                    <option value="unisex">Unisex</option>
                    <option value="men">Men</option>
                    <option value="women">Women</option>
                  </select>
                </div>

                <div className="admin-field">
                  <label htmlFor="sizes">Sizes</label>
                  <input
                    id="sizes"
                    name="sizes"
                    value={form.sizes}
                    onChange={handleChange}
                    placeholder="S, M, L, XL"
                  />
                  <small className="admin-muted">Separate with commas.</small>
                </div>

                <div className="admin-field">
                  <label htmlFor="colors">Colors</label>
                  <input
                    id="colors"
                    name="colors"
                    value={form.colors}
                    onChange={handleChange}
                    placeholder="Black, White"
                  />
                  <small className="admin-muted">Separate with commas.</small>
                </div>

                <div className="admin-field admin-field-full">
                  <label htmlFor="images">Image URLs</label>
                  <textarea
                    id="images"
                    name="images"
                    value={form.images}
                    onChange={handleChange}
                    placeholder="https://example.com/product.jpg"
                    rows={2}
                  />
                  <small className="admin-muted">
                    Add image URLs separated by commas.
                  </small>
                </div>

                <div className="admin-field admin-field-full">
                  <label className="admin-checkbox">
                    <input
                      type="checkbox"
                      name="isFeatured"
                      checked={form.isFeatured}
                      onChange={handleChange}
                    />
                    <span>Feature this product in the store</span>
                  </label>
                </div>
              </div>

              <div className="admin-form-actions">
                {editingId && (
                  <button
                    type="button"
                    className="admin-button"
                    onClick={resetForm}
                    disabled={saving}
                  >
                    Cancel edit
                  </button>
                )}

                <button
                  type="submit"
                  className="admin-button admin-button-primary"
                  disabled={saving}
                >
                  {saving
                    ? 'Saving...'
                    : editingId
                      ? 'Save changes'
                      : 'Create product'}
                </button>
              </div>
            </form>
          </section>

          <section className="admin-panel">
            <div className="admin-panel-header">
              <div>
                <h2 className="admin-panel-title">Your products</h2>
                <p className="admin-muted">
                  {pagination?.total ?? 0} {debouncedSearch ? 'matching' : 'total'} products
                </p>
              </div>

              <button
                type="button"
                className="admin-button"
                onClick={reloadProducts}
                disabled={loading}
              >
                {loading ? 'Refreshing...' : <><Icon name="refresh" /> Refresh</>}
              </button>
            </div>

            <div className="admin-table-toolbar">
              <input
                className="admin-search"
                type="search"
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setLoading(true);
                  setPage(1);
                }}
                placeholder="Search by product, category, or gender..."
                aria-label="Search products"
              />
            </div>

            {loading ? (
              <div className="admin-empty">Loading products...</div>
            ) : products.length === 0 ? (
              <div className="admin-empty">
                <strong>No products found</strong>
                <p className="admin-muted">
                  {search
                    ? 'Try a different search term.'
                    : 'Create your first product using the form above.'}
                </p>
              </div>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>PRODUCT</th>
                      <th>CATEGORY</th>
                      <th>GENDER</th>
                      <th>PRICE</th>
                      <th>STOCK</th>
                      <th>FEATURED</th>
                      <th>ACTIONS</th>
                    </tr>
                  </thead>

                  <tbody>
                    {products.map((product) => {
                      const stock = Number(product.stock) || 0;

                      return (
                        <tr key={product._id}>
                          <td>
                            <div className="admin-product-name">
                              {product.name}
                            </div>
                            <div className="admin-muted">
                              ID: {product._id?.slice(-6) || '—'}
                            </div>
                          </td>

                          <td>{product.category || '—'}</td>
                          <td>{product.gender || 'Unisex'}</td>
                          <td>{formatPrice(product.price)}</td>

                          <td>
                            <span
                              className={`admin-stock ${
                                stock === 0
                                  ? 'admin-stock-out'
                                  : stock <= 5
                                    ? 'admin-stock-low'
                                    : ''
                              }`}
                            >
                              {stock === 0
                                ? 'Out of stock'
                                : stock <= 5
                                  ? `${stock} left`
                                  : stock}
                            </span>
                          </td>

                          <td>{product.isFeatured ? 'Yes' : 'No'}</td>

                          <td>
                            <div className="admin-row-actions">
                              <button
                                type="button"
                                className="admin-button"
                                onClick={() => handleEdit(product)}
                              >
                                Edit
                              </button>

                              <button
                                type="button"
                                className="admin-button admin-button-danger"
                                onClick={() => handleDelete(product)}
                              >
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {!loading && (
              <Pagination
                pagination={pagination}
                onPageChange={(next) => {
                  setLoading(true);
                  setPage(next);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                itemLabel="products"
              />
            )}
          </section>

    </AdminLayout>
  );
}

export default AdminProducts;
