import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import {
  getDashboardStats,
  getAllOrders,
} from '../services/adminService.js';
import AdminLayout, {
  Notice,
  StatusPill,
} from '../components/AdminLayout.jsx';
import {
  STATUS_ORDER,
  STATUS_TONE,
  formatCurrency,
  formatDate,
  orderNumber,
  statusLabel,
} from '../utils/adminFormat.js';
import '../styles/admin.css';

// Segment colours follow the status tone palette.
const TONE_COLOR = {
  info: 'var(--adm-info)',
  progress: 'var(--adm-progress)',
  success: 'var(--adm-success)',
  danger: 'var(--adm-danger)',
  warning: 'var(--adm-warning)',
  neutral: 'var(--adm-muted)',
};

const today = () =>
  new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

const AdminDashboard = () => {
  const { token } = useAuth();

  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!token) {
      setError('Your session has ended. Please log in again.');
      setLoading(false);
      return undefined;
    }

    let active = true;

    const load = async () => {
      setLoading(true);
      setError('');

      const [statsResult, ordersResult] = await Promise.allSettled([
        getDashboardStats(token),
        getAllOrders(token),
      ]);

      if (!active) return;

      if (statsResult.status === 'fulfilled') {
        setStats(statsResult.value);
      } else {
        setError(
          statsResult.reason?.message ||
            'Unable to load store statistics.'
        );
      }

      if (ordersResult.status === 'fulfilled') {
        setRecentOrders(
          Array.isArray(ordersResult.value)
            ? ordersResult.value.slice(0, 6)
            : []
        );
      }

      setLoading(false);
    };

    load();

    return () => {
      active = false;
    };
  }, [token]);

  const byStatus = stats?.orders?.byStatus || {};
  const totalOrders = stats?.orders?.total || 0;
  const waitingOrders = byStatus.PLACED || 0;
  const products = stats?.products || {};

  return (
    <AdminLayout
      title="Overview"
      subtitle={today()}
      actions={
        <Link
          className="admin-button admin-button-primary"
          to="/admin/products"
        >
          Manage products
        </Link>
      }
    >
      {error && (
        <Notice tone="error">
          {error}{' '}
          <button
            type="button"
            className="admin-link-button"
            onClick={() => window.location.reload()}
          >
            Try again
          </button>
        </Notice>
      )}

      {loading && !stats && (
        <p className="admin-empty">Loading store statistics…</p>
      )}

      {stats && (
        <>
          <section className="admin-metrics" aria-label="Key figures">
            <div className="admin-metric">
              <div className="admin-metric-label">Orders</div>
              <div className="admin-metric-value">{totalOrders}</div>
              <div className="admin-metric-note">All time</div>
            </div>

            <div className="admin-metric">
              <div className="admin-metric-label">Order value</div>
              <div className="admin-metric-value">
                {formatCurrency(stats.totalOrderValue)}
              </div>
              <div className="admin-metric-note">Excludes cancelled</div>
            </div>

            <div className="admin-metric">
              <div className="admin-metric-label">Paid revenue</div>
              <div className="admin-metric-value">
                {formatCurrency(stats.paidRevenue)}
              </div>
              <div className="admin-metric-note">Payment confirmed</div>
            </div>

            <div className="admin-metric">
              <div className="admin-metric-label">In stock</div>
              <div className="admin-metric-value">
                {products.inStock ?? 0}
                <span className="admin-muted"> / {products.total ?? 0}</span>
              </div>
              <div className="admin-metric-note">Products available</div>
            </div>
          </section>

          <div className="admin-two-col">
            <section className="admin-panel">
              <div className="admin-panel-header">
                <div>
                  <h2 className="admin-panel-title">Order pipeline</h2>
                  <p className="admin-panel-note">
                    Where every order sits right now
                  </p>
                </div>
                <Link className="admin-link-button" to="/admin/orders">
                  All orders
                </Link>
              </div>

              {totalOrders === 0 ? (
                <p className="admin-empty">
                  No orders yet. They will appear here once customers
                  check out.
                </p>
              ) : (
                <>
                  <div
                    className="admin-pipeline"
                    role="img"
                    aria-label="Share of orders by status"
                  >
                    {STATUS_ORDER.map((status) => {
                      const count = byStatus[status] || 0;

                      if (!count) return null;

                      return (
                        <span
                          key={status}
                          style={{
                            width: `${(count / totalOrders) * 100}%`,
                            background:
                              TONE_COLOR[STATUS_TONE[status]] ||
                              TONE_COLOR.neutral,
                          }}
                        />
                      );
                    })}
                  </div>

                  <ul className="admin-legend">
                    {STATUS_ORDER.map((status) => {
                      const count = byStatus[status] || 0;
                      const share = totalOrders
                        ? Math.round((count / totalOrders) * 100)
                        : 0;

                      return (
                        <li key={status}>
                          <span
                            className="admin-swatch"
                            style={{
                              background:
                                TONE_COLOR[STATUS_TONE[status]] ||
                                TONE_COLOR.neutral,
                            }}
                            aria-hidden="true"
                          />
                          <span>{statusLabel(status)}</span>
                          <span className="admin-legend-count">
                            {count}
                          </span>
                          <span className="admin-legend-share">
                            {share}%
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </>
              )}
            </section>

            <section className="admin-panel">
              <div className="admin-panel-header">
                <div>
                  <h2 className="admin-panel-title">Needs attention</h2>
                  <p className="admin-panel-note">
                    Work that is waiting on you
                  </p>
                </div>
              </div>

              <ul className="admin-attention">
                <li>
                  <div>
                    <strong>Orders to confirm</strong>
                    <div className="admin-muted">
                      Placed but not yet confirmed
                    </div>
                  </div>
                  <Link
                    className="admin-attention-figure"
                    to="/admin/orders"
                    aria-label={`${waitingOrders} orders to confirm`}
                  >
                    {waitingOrders}
                  </Link>
                </li>

                <li>
                  <div>
                    <strong>Out of stock</strong>
                    <div className="admin-muted">
                      Hidden from customers until restocked
                    </div>
                  </div>
                  <Link
                    className={`admin-attention-figure${
                      products.outOfStock ? ' is-alert' : ''
                    }`}
                    to="/admin/products"
                    aria-label={`${products.outOfStock ?? 0} products out of stock`}
                  >
                    {products.outOfStock ?? 0}
                  </Link>
                </li>

                <li>
                  <div>
                    <strong>Low stock</strong>
                    <div className="admin-muted">
                      One to five units left
                    </div>
                  </div>
                  <Link
                    className="admin-attention-figure"
                    to="/admin/products"
                    aria-label={`${products.lowStock ?? 0} products low on stock`}
                  >
                    {products.lowStock ?? 0}
                  </Link>
                </li>
              </ul>
            </section>
          </div>

          <section className="admin-panel">
            <div className="admin-panel-header">
              <div>
                <h2 className="admin-panel-title">Recent orders</h2>
                <p className="admin-panel-note">
                  The six most recent orders
                </p>
              </div>
              <Link className="admin-link-button" to="/admin/orders">
                View all orders
              </Link>
            </div>

            {recentOrders.length === 0 ? (
              <p className="admin-empty">No orders to show yet.</p>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Order</th>
                      <th>Customer</th>
                      <th>Placed</th>
                      <th className="num">Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order._id}>
                        <td>
                          <Link
                            className="admin-link-button"
                            to={`/admin/orders?open=${order._id}`}
                          >
                            {orderNumber(order._id)}
                          </Link>
                        </td>
                        <td>
                          {order.shippingAddress?.name ||
                            order.user?.name ||
                            '—'}
                        </td>
                        <td>{formatDate(order.createdAt)}</td>
                        <td className="num">
                          {formatCurrency(order.totalAmount)}
                        </td>
                        <td>
                          <StatusPill status={order.orderStatus} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}

      <footer className="admin-muted admin-page-footer">
        Threads.com store admin
      </footer>
    </AdminLayout>
  );
};

export default AdminDashboard;
