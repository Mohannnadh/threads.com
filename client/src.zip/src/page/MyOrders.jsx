
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { getMyOrdersPage } from '../services/orderService.js';
import Pagination from '../components/Pagination.jsx';

const PAGE_SIZE = 10;

const MyOrders = () => {
  const { token } = useAuth();

  const [orders, setOrders] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Loads the requested page of orders whenever the page or login changes.
  useEffect(() => {
    if (!token) return undefined;

    let active = true;

    const loadOrders = async () => {
      try {
        const result = await getMyOrdersPage(token, { page, limit: PAGE_SIZE });

        if (!active) return;

        // If the current page no longer exists, step back to the last page.
        if (result.orders.length === 0 && result.pagination.totalPages > 0 && page > result.pagination.totalPages) {
          setPage(result.pagination.totalPages);
          return;
        }

        setError('');
        setOrders(result.orders);
        setPagination(result.pagination);
      } catch (err) {
        if (active) setError(err.message || 'Failed to load your orders.');
      } finally {
        if (active) setLoading(false);
      }
    };

    loadOrders();

    return () => {
      active = false;
    };
  }, [token, page]);

  const formatDate = (date) =>
    new Date(date).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });

  if (loading) {
    return <main style={{ padding: 60 }}>Loading your orders...</main>;
  }

  return (
    <main
      style={{
        maxWidth: 1100,
        margin: '0 auto',
        padding: '60px 24px 100px',
        color: '#111',
      }}
    >
      <p
        style={{
          fontSize: 11,
          letterSpacing: '0.15em',
          color: '#777',
        }}
      >
        YOUR ACCOUNT / ORDER HISTORY
      </p>

      <h1 style={{ fontSize: 42, fontWeight: 500 }}>
        MY ORDERS
      </h1>

      {error && (
        <p role="alert" style={{ color: '#b00020' }}>
          {error}
        </p>
      )}

      {!error && orders.length === 0 && (
        <section style={{ padding: '40px 0' }}>
          <h2>No orders yet.</h2>
          <p style={{ color: '#666' }}>
            Your orders will appear here after checkout.
          </p>
          <Link to="/products">Explore products</Link>
        </section>
      )}

      {orders.map((order) => (
        <article
          key={order._id}
          style={{
            border: '1px solid #ddd',
            padding: 24,
            marginTop: 24,
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: 16,
              flexWrap: 'wrap',
            }}
          >
            <div>
              <p style={{ color: '#777', fontSize: 12 }}>
                ORDER PLACED
              </p>
              <p>{formatDate(order.createdAt)}</p>
            </div>

            <div>
              <p style={{ color: '#777', fontSize: 12 }}>
                ORDER STATUS
              </p>
              <strong>{order.orderStatus}</strong>
            </div>

            <div>
              <p style={{ color: '#777', fontSize: 12 }}>
                TOTAL
              </p>
              <strong>
                ₹{Number(order.totalAmount).toLocaleString('en-IN')}
              </strong>
            </div>
          </div>

          <hr style={{ border: 0, borderTop: '1px solid #ddd' }} />

          <h3>Items</h3>

          {order.items.map((item, index) => (
            <div
              key={`${item.product}-${index}`}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                gap: 16,
                marginBottom: 12,
              }}
            >
              <span>
                {item.name} × {item.quantity}
                {item.size && ` · Size ${item.size}`}
              </span>

              <span>
                ₹{(
                  Number(item.price) * Number(item.quantity)
                ).toLocaleString('en-IN')}
              </span>
            </div>
          ))}

          <p style={{ color: '#666', fontSize: 13 }}>
            Payment: {order.paymentMethod} · {order.paymentStatus}
          </p>
        </article>
      ))}

      <Pagination
        pagination={pagination}
        itemLabel="orders"
        onPageChange={(next) => {
          setLoading(true);
          setPage(next);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </main>
  );
};

export default MyOrders;
